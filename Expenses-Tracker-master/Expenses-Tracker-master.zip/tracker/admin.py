from django.contrib import admin

# Register your models here.
from . models import Item

admin.site.register(Item) #registering the model
